@extends('app')

@section('content')
	
	@include('view.slide', ['title' => 'contact us'])
	
	@include('view.contact')
	
@endsection