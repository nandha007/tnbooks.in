<strong>Hi, Admin</strong>

<p>Name: {{ $input['name'] }}</p>
<p>Email: {{ $input['email'] }}</p>
<p>Contact no: {{ $input['contact_no'] }}</p> 
<p>Subject: {{ $input['subject'] }}</p> 
<p>Message: <br />{{ $input['message'] }}</p>