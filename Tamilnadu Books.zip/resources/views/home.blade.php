@extends('app')

@section('content')
	
	@include('view.slider')
	
	@include('view.featured')
	
	@include('view.catalogue')

@endsection
