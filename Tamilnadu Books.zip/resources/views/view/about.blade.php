<!-- begin:content -->
<div class="page-content">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ol class="breadcrumb">
				  <li><a href="{{ route('index') }}">Home</a></li>
				  <li class="active">About Us</li>
				</ol>
			</div>
		</div>
		
		<div class="row padd20-top-btm">
			<!-- <div class="col-md-4 col-sm-4">
				<div class="about-container">
					<div class="about-photos">
						<i class="fa fa-gift"></i>
					</div>
				</div>
			</div> -->
			<div class="col-md-12 col-sm-12">
				<div class="col-md-12 col-sm-12">
					<!-- <h3>Tamilnadu Books</h3> -->
					<p>Tamilnadu Books was started during the year 2010 with an intention of making book varieties available to schools and public with ease and we are dedicated to do so.  Taking this to another step we are introducing this Tamilnadu Books online portal bringing you close to us.</p>
					<p>Our inventory currently includes more than 2000+ varieties of books, from which you can select depending on your need.  Whatever it might be, we have books for all occasion. We do</p>
					<ul>
						<li>Organize School Book Fairs</li>
						<li>Sell School academic books</li>
						<li>Sell Prize books</li>
						<li>Replenish books for your libraries and</li>
						<li>Sell other children, story and novel books as well.</li>
					</ul>
					<p>We are specialised school book fair organizers and had been doing it for last 3 years in most of the schools in Tamilnadu.We supply school academic books, you can get it touch with us, get specimens from our inventory which hold books from school book publishers from all over India.  We do also supply samacheerkalvi books also.</p>
					<p>We are always looking for opportunities to serve you better and to make you reach us easier. If you do have any queries please feel free to get in touch with us through the Contact Us page.  We would be happy to help you.</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- end:content