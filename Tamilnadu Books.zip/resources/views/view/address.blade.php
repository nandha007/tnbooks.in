<div class="col-md-12 col-sm-12">

	<h3>CONTACT DETAILS</h3>

	<div class="contact">

		<span><i class="fa fa-home"></i></span>
		<p>
			<strong>Tamilnadu Books</strong>,
			<br>
			31A/16, Devanger Colony,
			<br>
			Salai Road,
			<br>
			Woraiyur, Trichy 620003.
		</p>

	</div>

	<div class="contact">
		<span><i class="fa fa-phone fa-3"></i></span>
		<p>
			<a href="tel:+919443686197">94436 86197</a>, <a href="tel:+919659299661">96592 99661</a>
		</p>
	</div>

	<div class="contact">
		<span><i class="fa fa-envelope-o"></i></span>
		<p>
			<a href="mailto:contact@tnbooks.in">contact@tnbooks.in</a>, <a href="mailto:tamilnadubooks1@gmail.com">tamilnadubooks1@gmail.com</a>
		</p>

	</div>

</div>	