<!-- begin:heading -->
<div class="heads" style="background: url(' {{ asset('img/img02.jpg') }} ') center center;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2><span>//</span> {{ $title }}</h2>
			</div>
		</div>
	</div>
</div>
<!-- end:heading -->