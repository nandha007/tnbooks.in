@extends('app')

@section('content')
	
	@include('view.slide')
	
	@include('view.about')
	
	@include('view.footer')
	
	@include('view.copyright')
	
@endsection