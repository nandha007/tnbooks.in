@extends('app')

@section('content')
	
	@include('view.slide')
	
	@include('view.contact')
	
	@include('view.footer')
	
	@include('view.copyright')
	
@endsection