<div class="col-md-12 col-sm-12">
	<div class="alert alert-danger alert-dismissible hide" role="alert">
	  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	  <ul class="errors">
	  </ul>
	</div>

	<div class="alert alert-success alert-dismissible hide" role="alert">
	  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	  <div class="message">
	  </div>
	</div>
</div>

<div class="clearfix"></div>

{!! Form::open(array('method' => 'post', 'id' => 'contactFrom')) !!}

<div class="col-md-5 col-sm-5">
	<h3>send message</h3>

	{!! Form::text('name', '', array('class' => 'form-control', 'placeholder' => 'Enter your name')) !!}
	{!! Form::email('email', '', array('class' => 'form-control', 'placeholder' => 'Enter your mail')) !!}
	{!! Form::text('contact_no', '', array('class' => 'form-control', 'placeholder' => 'Enter your contact no', 'maxlength' => 10)) !!}
	{!! Form::text('subject', '', array('class' => 'form-control', 'placeholder' => 'Enter your subject')) !!}

</div>

<div class="col-md-7 col-sm-7">

	{!! Form::textarea('message', '', array('size' => '30x10', 'class' => 'form-control', 'placeholder' => 'Type your message')) !!}
	{!! Form::submit('Send Message', array('class' => 'btn btn-green btn-block btn-lg')) !!}

</div>

{!! Form::close() !!}

<script type="text/javascript">

	 $("#contactFrom").on('submit', function(e) {

		e.preventDefault();
		$('.errors').html('').parent().addClass('hide');
		$('.message').html('').parent().addClass('hide');

		$(this).waitMe({
			effect : 'bounce',
			text : 'Please wait...',
			bg : 'rgba(0,0,0,0.1)',
			color : '#16A085'
		});

		$.ajax({
			type: 'post',
			url:  "{{ route('contactAction') }}",
			data: $("#contactFrom").serializeArray(),
			dataType: 'json',
			success: function(data) {
				console.log(data);

				$("#contactFrom").waitMe('hide');
				
				$('.message').append( data.message ).parent().removeClass('hide');
				$('#contactFrom').trigger("reset");
				//$("#contactFrom").reset();
			},
			error: function(data) {
				var errors = data.responseJSON;
				console.log(errors);

				$("#contactFrom").waitMe('hide');

				$.each ( errors, function (key, error) {
					$('.errors').append('<li>' + error[0] + '</li>').parent().removeClass('hide');
				});
			}
		});
	});

	

</script>