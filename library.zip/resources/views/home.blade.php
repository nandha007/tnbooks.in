@extends('app')

@section('content')
	
	@include('view.slider')
	
	@include('view.tagline')
	
	@include('view.featured')
	
	@include('view.catalogue')
	
	@include('view.testimoni')
	
	{{-- @include('view.blog') --}}
	
	@include('view.footer')
	
	@include('view.copyright')
	
@endsection
