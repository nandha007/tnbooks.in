<!-- begin:blog -->
<div id="blog">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="heading-title">
					<h2>From Blog</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4 col-sm-4">
				<div class="blog-container">
					<div class="blog-date">
						<i class="fa fa-calendar"></i>
						<span class="meta-date">26</span>
						<span class="meta-month-year">MAR 2014</span>
					</div>
					<h3><a href="single.html">the post title</a></h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus quis lectus metus, at posuere neque.</p>
					<p><a href="single.html" class="btn btn-green">Read more &raquo;</a></p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="blog-container">
					<div class="blog-date">
						<i class="fa fa-calendar"></i>
						<span class="meta-date">03</span>
						<span class="meta-month-year">FEB 2014</span>
					</div>
					<h3><a href="single.html">the post title</a></h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus quis lectus metus, at posuere neque.</p>
					<p><a href="single.html" class="btn btn-green">Read more &raquo;</a></p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="blog-container">
					<div class="blog-date">
						<i class="fa fa-calendar"></i>
						<span class="meta-date">19</span>
						<span class="meta-month-year">JAN 2014</span>
					</div>
					<h3><a href="single.html">the post title</a></h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus quis lectus metus, at posuere neque.</p>
					<p><a href="single.html" class="btn btn-green">Read more &raquo;</a></p>
				</div>
			</div>
			
		</div>
	</div>
</div>
<!-- end:blog -->