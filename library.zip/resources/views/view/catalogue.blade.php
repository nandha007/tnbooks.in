<!-- begin:catalogue -->
<div id="catalogue">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="heading-title">
					<h2>Most Wanted</h2>
					<p>The best of the best item most wanted in 2013</p>
				</div>	
			</div>
		</div>
		<div class="row">
			<div class="col-md-3 col-sm-4 col-xs-12">
				<div class="thumbnail">
				  <div class="caption-img" style="background: url(img/manuk.jpg);"></div>
				  <div class="caption-details">
					<h3>Border Canary</h3>
					<span class="price">$200</span>
				  </div>
				  <a href="detail.html"><div class="caption-link"><i class="fa fa-plus"></i></div></a>
				</div>
			</div>
			<div class="col-md-3 col-sm-4 col-xs-12">
				<div class="thumbnail">
				  <div class="caption-img" style="background: url(img/manuk.jpg);"></div>
				  <div class="caption-details">
					<h3>Border Canary</h3>
					<span class="price">$200</span>
				  </div>
				  <a href="detail.html"><div class="caption-link"><i class="fa fa-plus"></i></div></a>
				</div>
			</div>
			<div class="col-md-3 col-sm-4 col-xs-12">
				<div class="thumbnail">
				  <div class="caption-img" style="background: url(img/manuk.jpg);"></div>
				  <div class="caption-details">
					<h3>Border Canary</h3>
					<span class="price">$200</span>
				  </div>
				  <a href="detail.html"><div class="caption-link"><i class="fa fa-plus"></i></div></a>
				</div>
			</div>
			<div class="col-md-3 col-sm-4 col-xs-12">
				<div class="thumbnail">
				  <div class="caption-img" style="background: url(img/manuk.jpg);"></div>
				  <div class="caption-details">
					<h3>Border Canary</h3>
					<span class="price">$200</span>
				  </div>
				  <a href="detail.html"><div class="caption-link"><i class="fa fa-plus"></i></div></a>
				</div>
			</div>
			<div class="col-md-3 col-sm-4 col-xs-12">
				<div class="thumbnail">
				  <div class="caption-img" style="background: url(img/manuk.jpg);"></div>
				  <div class="caption-details">
					<h3>Border Canary</h3>
					<span class="price">$200</span>
				  </div>
				  <a href="detail.html"><div class="caption-link"><i class="fa fa-plus"></i></div></a>
				</div>
			</div>
			<div class="col-md-3 col-sm-4 col-xs-12">
				<div class="thumbnail">
				  <div class="caption-img" style="background: url(img/manuk.jpg);"></div>
				  <div class="caption-details">
					<h3>Border Canary</h3>
					<span class="price">$200</span>
				  </div>
				  <a href="detail.html"><div class="caption-link"><i class="fa fa-plus"></i></div></a>
				</div>
			</div>
			<div class="col-md-3 col-sm-4 col-xs-12">
				<div class="thumbnail">
				  <div class="caption-img" style="background: url(img/manuk.jpg);"></div>
				  <div class="caption-details">
					<h3>Border Canary</h3>
					<span class="price">$200</span>
				  </div>
				  <a href="detail.html"><div class="caption-link"><i class="fa fa-plus"></i></div></a>
				</div>
			</div>
			<div class="col-md-3 col-sm-4 col-xs-12">
				<div class="thumbnail">
				  <div class="caption-img" style="background: url(img/manuk.jpg);"></div>
				  <div class="caption-details">
					<h3>Border Canary</h3>
					<span class="price">$200</span>
				  </div>
				  <a href="detail.html"><div class="caption-link"><i class="fa fa-plus"></i></div></a>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- end:catalogue -->