<!-- begin:contact -->
<div class="page-content contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li class="active">Contact Us</li>
				</ol>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12 text-center">
				<h3>Lorem ipsum dolor sit amet</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.</p>
			</div>
		</div>
		<div class="row padd20-top-btm">

			@include('forms.contact')

		</div>
	</div>
</div>

<div id="maps"></div>
<!-- end:contact -->