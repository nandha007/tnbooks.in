<!-- begin:copyright -->
<div id="copyright">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<small>Copyright &copy; 2013 Dodolan Manuk All Right Reserved. Made With <i class="fa fa-heart-o"></i> by Afriq</small>
			</div>
		</div>
	</div>
</div>
<!-- end:copyright -->