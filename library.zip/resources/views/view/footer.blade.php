<!-- begin:footer -->
<div id="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h3>dodolan manuk</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus quis lectus metus,<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>

				<ul class="list-unstyled social-icon">
				  <li><a href="#" rel="tooltip" title="Facebook" class="icon-facebook"><span><i class="fa fa-facebook-square"></i></span></a></li>
				  <li><a href="#" rel="tooltip" title="Twitter" class="icon-twitter"><span><i class="fa fa-twitter"></i></span></a></li>
				  <li><a href="#" rel="tooltip" title="Linkedin" class="icon-linkedin"><span><i class="fa fa-linkedin"></i></span></a></li>
				  <li><a href="#" rel="tooltip" title="Instagram" class="icon-gplus"><span><i class="fa fa-google-plus"></i></span></a></li>
				  <li><a href="#" rel="tooltip" title="Instagram" class="icon-instagram"><span><i class="fa fa-instagram"></i></span></a></li>
				</ul>

				<div class="sitemap">
					<ul>
						<li><a href="index.html">HOME</a></li>
						<li><a href="about.html">ABOUT</a></li>
						<li><a href="profile.html">PROFILE</a></li>
						<li><a href="contact.html">CONTACT</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- end:footer -->