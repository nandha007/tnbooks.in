<!-- begin:heading -->
<div class="heads" style="background: url(img/img02.jpg) center center;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2><span>//</span> contact us</h2>
			</div>
		</div>
	</div>
</div>
<!-- end:heading -->