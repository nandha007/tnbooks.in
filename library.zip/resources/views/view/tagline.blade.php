<!-- begin:tagline -->	
<div id="tagline">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>Hello There, This is 'Dodolan Manuk' Themes</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus quis lectus metus, at posuere neque. Sed pharetra nibh eget orci convallis at posuere leo convallis. Sed blandit augue vitae augue scelerisque bibendum.</p>
			</div>
		</div>
	</div>
</div>
<!-- end:tagline -->