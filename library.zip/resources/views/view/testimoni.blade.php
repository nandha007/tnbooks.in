<!-- begin:testimoni -->
<div id="testimoni">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="testimoni-icon"><i class="fa fa-quote-left"></i></div>
				<h3>Our Testimonials</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div id="testi" class="carousel slide" data-ride="carousel">
				  <div class="carousel-inner">
					<div class="item active">
					   <p class="testimoni-item">Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
						<h4>&#8212; John doe, Scriptlabs &#8212;</h4>
					</div>
					<div class="item">
					   <p class="testimoni-item">Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
						<h4>&#8212; John doe, Scriptlabs &#8212;</h4>
					</div>
					<div class="item">
					   <p class="testimoni-item">Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
						<h4>&#8212; John doe, Scriptlabs &#8212;</h4>
					</div>
				  </div>
				  <a class="left carousel-control" href="#testi" data-slide="prev">&lsaquo;</a>
				  <a class="right carousel-control" href="#testi" data-slide="next">&rsaquo;</a>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- end:testimoni -->